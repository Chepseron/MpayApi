/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author PROBOOK
 */
@Entity
@Table(name = "bank2")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bank2.findAll", query = "SELECT b FROM Bank2 b"),
    @NamedQuery(name = "Bank2.findByIdbank1", query = "SELECT b FROM Bank2 b WHERE b.idbank1 = :idbank1"),
    @NamedQuery(name = "Bank2.findByTranID", query = "SELECT b FROM Bank2 b WHERE b.tranID = :tranID"),
    @NamedQuery(name = "Bank2.findByAmount", query = "SELECT b FROM Bank2 b WHERE b.amount = :amount"),
    @NamedQuery(name = "Bank2.findByDatecreated", query = "SELECT b FROM Bank2 b WHERE b.datecreated = :datecreated"),
    @NamedQuery(name = "Bank2.findByNarration", query = "SELECT b FROM Bank2 b WHERE b.narration = :narration"),
    @NamedQuery(name = "Bank2.findByMobilenumber", query = "SELECT b FROM Bank2 b WHERE b.mobilenumber = :mobilenumber"),
    @NamedQuery(name = "Bank2.findByOutlet", query = "SELECT b FROM Bank2 b WHERE b.outlet = :outlet"),
    @NamedQuery(name = "Bank2.findByAccountNumber", query = "SELECT b FROM Bank2 b WHERE b.accountNumber = :accountNumber"),
    @NamedQuery(name = "Bank2.findByName", query = "SELECT b FROM Bank2 b WHERE b.name = :name")})
public class Bank2 implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idbank1")
    private Integer idbank1;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "tranID")
    private String tranID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "amount")
    private int amount;
    @Column(name = "datecreated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datecreated;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "narration")
    private String narration;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mobilenumber")
    private int mobilenumber;
    @Basic(optional = false)
    @NotNull
    @Column(name = "outlet")
    private int outlet;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "accountNumber")
    private String accountNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "name")
    private String name;

    public Bank2() {
    }

    public Bank2(Integer idbank1) {
        this.idbank1 = idbank1;
    }

    public Bank2(Integer idbank1, String tranID, int amount, String narration, int mobilenumber, int outlet, String accountNumber, String name) {
        this.idbank1 = idbank1;
        this.tranID = tranID;
        this.amount = amount;
        this.narration = narration;
        this.mobilenumber = mobilenumber;
        this.outlet = outlet;
        this.accountNumber = accountNumber;
        this.name = name;
    }

    public Integer getIdbank1() {
        return idbank1;
    }

    public void setIdbank1(Integer idbank1) {
        this.idbank1 = idbank1;
    }

    public String getTranID() {
        return tranID;
    }

    public void setTranID(String tranID) {
        this.tranID = tranID;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getDatecreated() {
        return datecreated;
    }

    public void setDatecreated(Date datecreated) {
        this.datecreated = datecreated;
    }

    public String getNarration() {
        return narration;
    }

    public void setNarration(String narration) {
        this.narration = narration;
    }

    public int getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(int mobilenumber) {
        this.mobilenumber = mobilenumber;
    }

    public int getOutlet() {
        return outlet;
    }

    public void setOutlet(int outlet) {
        this.outlet = outlet;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idbank1 != null ? idbank1.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bank2)) {
            return false;
        }
        Bank2 other = (Bank2) object;
        if ((this.idbank1 == null && other.idbank1 != null) || (this.idbank1 != null && !this.idbank1.equals(other.idbank1))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Bank2[ idbank1=" + idbank1 + " ]";
    }
    
}
